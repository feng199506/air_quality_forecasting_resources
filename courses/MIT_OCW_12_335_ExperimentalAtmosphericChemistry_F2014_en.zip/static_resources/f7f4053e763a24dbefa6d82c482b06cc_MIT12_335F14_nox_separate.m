
no_index=NOX_NO(:,3)==1;
nox_index=NOX_NO(:,3)==4;

data_NO=NOX_NO(no_index, :);
data_NOX=NOX_NO(nox_index, :);