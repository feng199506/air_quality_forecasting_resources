% This routine downloads weather data from Weather Underground and saves it as .csv in the 
% Matlab folder.
% Specify start and stop day. You will also need to change the month inside the URL once October
% starts.

start_day = 25;
stop_day = 26;


for i = start_day:stop_day;
    url_name = sprintf('http://www.wunderground.com/weatherstation/WXDailyHistory.asp?ID=KMACAMBR9&day=%d&month=9&year=2014&graphspan=day&format=1', i);
    file_name = sprintf('september.%d.csv',i);
    file_name = urlwrite(url_name,file_name);
    open(file_name)
end