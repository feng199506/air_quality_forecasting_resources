%File to read raw NOx data
%clear the workspace

clear
clc

% Open the file

fid=fopen('NOx_test.txt','rt');

% Read the data to a cell array

a=textscan(fid,'%f %f %f %f %f %f %f %s %s %f','Delimiter',',','HeaderLines',11);
%Close the text file

fclose(fid);

% concatenate the date and time and format to Matlab serial time format
time=nan(length(a{1}),1);

for i=1:length(a{1})
    time(i)=datenum(sprintf('%s %s',a{8}{i},a{9}{i}),'dd/mm/yy HH:MM:SS');
end

% Store selected data in the final matlab file

NOX_NO=[time,a{2},a{10}];

clearvars -except NOX_NO
