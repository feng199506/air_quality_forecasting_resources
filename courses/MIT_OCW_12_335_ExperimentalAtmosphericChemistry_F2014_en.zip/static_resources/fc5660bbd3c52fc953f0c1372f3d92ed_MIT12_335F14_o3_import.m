%File to read raw O3 data
%clear the workspace

clear
clc

% Open the file

fid=fopen('Ozone.txt','rt');

% Read the data to a cell array

a=textscan(fid,'%f %f %f %f %f %f %f %s %s','Delimiter',',','HeaderLines',2);
%Close the text file

fclose(fid);

% concatenate the date and time and format to Matlab serial time format
time=nan(length(a{1}),1);

for i=1:length(a{1})
    time(i)=datenum(sprintf('%s %s',a{8}{i},a{9}{i}),'dd/mm/yy HH:MM:SS');
end

% Store selected data in the final matlab file

data_O3=[time,a{2}];

clearvars -except data_O3