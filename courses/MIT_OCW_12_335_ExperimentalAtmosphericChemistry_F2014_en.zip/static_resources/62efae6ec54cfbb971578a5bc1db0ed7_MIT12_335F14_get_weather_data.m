% This routine extracts time, temperature, wind direction and wind speed
% from a Weather Underground data .csv file that has already been imported into the Matlab
% workspace, preferably using the GUI import tool.



T = cell(290,1);
for i = 1:290;
    T{i,1} = Time{i+(i-1),1};
end

for i=1:290;
    T{i,1} = datenum(T{i,1},'yyyy-mm-dd HH:MM:SS');
end
T = cell2mat(T);

Temp = cell(290,1);
for i = 1:290;
    Temp{i,1} = TemperatureF{i+(i-1),1};
end

for i = 1:290;
    Temp{i,1} = str2double(Temp{i,1});
end
Temp = cell2mat(Temp);

WindDir = cell(290,1);
for i = 1:290;
    WindDir{i,1} = WindDirectionDegrees{i+(i-1),1};
end

for i = 1:290;
    WindDir{i,1} = str2double(WindDir{i,1});
end
WindDir = cell2mat(WindDir);

WindSpd = cell(290,1);
for i = 1:290;
    WindSpd{i,1} = WindSpeedMPH{i+(i-1),1};
end

for i = 1:290;
    WindSpd{i,1} = str2double(WindSpd{i,1});
end
WindSpd = cell2mat(WindSpd);
M = cat(2,T,Temp,WindDir,WindSpd);

clearvars -except M