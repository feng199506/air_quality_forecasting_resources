
% Put the O3 matrix in the workspace
%Store calibration data in an array

cal=[0,0.3;50,48;100,104;150,147;200,190]; % this is an example

p=polyfit(cal(:,2),cal(:,1),1);

y=polyval(p, cal(:,2));

O3_Calibrated(:,2)=polyval(p,data_O3(:,2));
O3_Calibrated(:,1)=data_O3(:,1);

plot(cal(:,2),cal(:,1),'ob','MarkerSize',6)
hold on
plot(cal(:,2),y,'-r')
ylim([0 200])
xlim([0 200])
xlabel('Ozone Monitor (ppb)')
ylabel('Ozone calibration source (ppb)')
text(cal(3,2),cal(2,1), strcat('S=', num2str(p(1)),' , Z=', num2str(p(2))))
