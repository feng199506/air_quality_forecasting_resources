%File to import raw PM data
%clear the workspace

%clear
clc

% Open the file

fid=fopen('DT10.txt','rt');

% Read the data to a cell array

a=textscan(fid,'%s %s %f','Delimiter',',','HeaderLines',30);
%Close the text file

fclose(fid);

% concatenate the date and time and format to Matlab serial time format
time=nan(length(a{end}),1);

for i=1:length(a{1})
    time(i)=datenum(sprintf('%s %s',a{1}{i},a{2}{i}),'mm/dd/yy HH:MM:SS');
end

% Store selected data in the final matlab file

data_PM25_3=[time,a{3}];

%clearvars -except PM