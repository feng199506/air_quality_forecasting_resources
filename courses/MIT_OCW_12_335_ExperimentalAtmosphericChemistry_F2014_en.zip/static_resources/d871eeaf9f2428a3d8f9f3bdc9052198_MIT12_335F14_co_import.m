%File to read raw CO data
%clear the workspace

clear
clc

% Open the file

fid=fopen('CO.csv','rt');

% Read the data to a cell array

a=textscan(fid,'%s %f %f %f %f %f %f %f','Delimiter',',','HeaderLines',1);
%Close the text file

fclose(fid);

% format the time to Matlab serial time format
time=nan(length(a{end}),1);

for i=1:length(a{1})
    time(i)=datenum(a{1}(i),'mm/dd/yy HH:MM');
end

% Store selected data in the final matlab file

data_CO=[time,a{2}];

clearvars -except data_CO