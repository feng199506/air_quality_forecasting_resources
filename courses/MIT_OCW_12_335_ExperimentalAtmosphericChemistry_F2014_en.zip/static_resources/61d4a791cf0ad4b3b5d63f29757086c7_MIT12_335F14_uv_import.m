%File to read raw UV data
%clear the workspace

clear
clc

% Open the file

fid=fopen('UV_09_25_2013.txt','rt');

% Read the data to a cell array

a=textscan(fid,'%s %s %f %f %f','Delimiter','\t','HeaderLines',2);
%Close the text file

fclose(fid);

% concatenate the date and time and format to Matlab serial time format
time=nan(length(a{end}),1);

for i=1:length(a{1})
    time(i)=datenum(sprintf('%s %s',a{1}{i},a{2}{i}),'mm/dd/yy HH:MM:SS PM');
end

% Store selected data in the final matlab file

UV=[time,a{3},a{4}, a{5}];

clearvars -except UV